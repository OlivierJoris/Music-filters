# Object-Oriented Programming

## Java files
- Demo.java is the echo filter

## Documentation & class hierarchy
Available at : http://www.student.montefiore.ulg.ac.be/~mgoffart/projects/oop/
